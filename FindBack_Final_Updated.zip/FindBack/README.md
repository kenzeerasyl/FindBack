# FindBack

AI Campus Lost Item Assistant — an educational, explainable search assistant.

## Final submission

The application brings A*, Bayesian inference, and Bellman planning into a live
search. The submission includes an executed notebook, a local browser app,
audited experiments, 46 Python tests and a browser workflow check.

- [Quick start in Russian](START_HERE_RU.md)
- [Standalone Colab notebook](FindBack_Demo.ipynb)
- [Defense script and questions](docs/DEFENSE.md)
- [Simulation results](results/REPORT.md)
- [Mathematical specification](docs/MODEL.md)

Python 3.10 or newer runs the app and experiments with the standard library.
The project was checked with Python 3.12.14 and Chrome. The notebook uses the
display tools provided by Colab or Jupyter. Node and Playwright are needed only
to repeat the browser check in `tests/browser_check.cjs`.

## Open FindBack

On Windows, double-click `Start FindBack.cmd` in the extracted project folder.
Keep the console open while using FindBack. The launcher uses the bundled Codex
Python if present, then tries the Windows Python launcher or the `python` command.

On any system with Python 3.10 or newer, open a terminal in the project folder:

```powershell
python -m findback.webapp --open
```

Open `http://127.0.0.1:8501/` if the browser does not open automatically. To use a
different port, add `--port 8502`. Press Ctrl+C in the console to stop the local
server. The application uses the Python standard library and browser features.

### Using the app

The browser interface is in Russian. Open **Новый поиск** to enter an item,
description, current position, last known location and time budget. A selected
last known location receives three times its original prior weight before
normalization. This is a modeling assumption. The current position only changes
walking distances. **Открыть пример** starts a reproducible manual walkthrough.

Choose a pin or a place in the list to preview its route. **Записать проверку**
records an inspection result. **Добавить подсказку** logs an existing report and
an optional note without charging time. **Настроить проходы** toggles access to
corridors. **Как это работает** contains Q values, model assumptions, the A*
exploration slider and the experiment comparison.

**Мои поиски** reopens a case with its recorded observations, notes and map edits.
Cases are saved in this browser at the local app address and restored by replaying
events when opened. The browser's data settings control retention. **Скачать
историю** exports a JSON record of the search, route and calculations.

See [the walkthrough](START_HERE_RU.md) for exact buttons and values for the live
demonstration.

## Run a complete simulated search

Open a terminal in the FindBack directory. All current modules use Python's
standard library only; no package installation is necessary.

```powershell
python -m findback.run --seed 42
python -m findback.run --scenario urgent --seed 7 --depth 3
python -m findback.run --policy nearest --seed 42
python -m findback.run --seed 7 --export results/my_episode.json
python -m findback.experiments --trials 100 --seed 1000 --depth 3
python -m findback.report
```

`findback.run` prints initial planner Q values and then executes the selected
policy. `findback.experiments` overwrites generated files in its output directory;
use `--out results_other` for a separate run. `findback.report --results results_other`
replays and audits exported observations, routes, beliefs and accounting, then
creates a readable REPORT.md. Run from the project directory. Depth 3 is the
default; depth 4 may be substantially slower.

Actual results are in `results/REPORT.md`, `summary.json`, `episodes.csv` and
`episodes.json`. The CSV is compact; JSON includes every episode step.

### Decision-model limitations

The actual task is partially observed. We plan in a belief-state MDP with exact
Bayesian posteriors and finite lookahead, not an MDP that observes the item.
There is no posterior quantization. Depth 3 means three planned decisions,
followed by replanning after each real observation, not a three-action episode.
Gamma discounts per decision; movement time is charged separately. STOP has
value zero. Information from ASK becomes valuable only through future actions.
The result is not claimed globally optimal for the full budget.

The two baselines visit each reachable, affordable site at most once and do not
ASK. Their outcomes compare whole strategies; they do not isolate only the
contribution of the planner. Hidden simulator truth is never passed to policies.

## Run Part 1

Python 3.10 or newer. No external packages are required for this release.
Open a terminal in the `FindBack` directory:

```powershell
python -m findback.demo
python -m findback.demo --scenario weak_reports
python -m findback.demo --scenario urgent
python -m findback.demo --scenario isolated_library
python -m findback.demo --json
python -m unittest discover -s tests -v
```

If your system uses the Windows Python launcher, replace `python` with `py`.
Use a UTF-8-capable terminal. Core input/output identifiers are English ASCII.

### Baseline example

The Library prior is 0.4. A yes report has likelihood 0.8 if the item is there
and 0.1 if it is elsewhere:

```
P(report) = 0.4*0.8 + 0.6*0.1 = 0.38
P(Library | report) = 0.32 / 0.38 = 0.842105...
```

Other posterior probabilities are Cafe (Cafeteria) 0.065789..., Classroom
0.039474..., Office 0.026316..., and Lab 0.026316.... The demonstration prints
the routes to **all** locations without claiming which action is optimal.

## Files

| File | Responsibility |
|---|---|
| `findback/domain.py` | Validated map, distributions, observation model and costs |
| `findback/astar.py` | A* and UCS, paths, costs and expanded nodes |
| `findback/bayes.py` | Bayesian calculations and duplicate event protection |
| `findback/scenarios.py` | JSON loader independent of working directory |
| `findback/demo.py` | Console demonstration and JSON output |
| `findback/decision_model.py` | Bellman lookahead, actions, outcomes and Q values |
| `findback/simulator.py` | Hidden world, baseline policies and episode execution |
| `findback/run.py` | Complete episode command-line interface |
| `findback/experiments.py` | Paired-seed experiments and statistical summaries |
| `findback/report.py` | Replay audit and readable results report |
| `findback/session.py`, `findback/webapp.py` | Interactive search state and local web server |
| `web/` | Campus map, probability bars, controls and calculation views |
| `scenarios.json` | Map and four reproducible scenario configurations |
| `tests/test_core.py` | Hand calculations, invariants and independent search tests |
| `tests/test_decisions.py` | Bellman calculations, information value and simulation tests |
| `tests/test_session.py`, `tests/browser_check.cjs` | Session checks and browser workflow verification |
| `docs/MODEL.md` | Mathematics, assumptions and planning contract |
| `FindBack_Demo.ipynb` | Portable notebook with saved output for all three algorithms |
| `tools/build_notebook.py` | Build and execute the notebook from project source |
| `docs/DEFENSE.md` | English demonstration script and questions |
| `docs/ROADMAP.md` | Completed deliverables |

## Scenario meanings

- `baseline`: informative reports, budget 30.
- `weak_reports`: less informative reports, same map and prior.
- `urgent`: budget 10; distant inspections may exceed the time budget.
- `isolated_library`: no route to Library, but the item may still be there.

Budgets are abstract time units, not measured walking minutes. All maps,
probabilities and costs are hypothetical. No university measurements or real
personal data are used. A single stationary item is in exactly one listed
location. The system cannot detect an item outside this set.

## Design principles

- A public belief is not the hidden simulator truth.
- No rounding during Bayesian calculations; formatting rounds only for display.
- Duplicate event IDs are rejected; correlated copied reports should not be
  entered with fresh IDs and treated as independent witnesses.
- A failed search is not proof of absence unless detection probability is one.
- An unreachable location retains its probability.
- Impossible observations raise an explicit error; no silent uniform fallback.
- Successful search means physically verified discovery (no false positives).
- Test evidence includes an independent BFS reference, not just A* vs UCS.

## Academic scope

The final system combines probabilistic reasoning, graph search and sequential
decision making. Source code, assumptions and numerical traces will remain
available for oral defense. AI-assisted authorship must be disclosed; every
team member should understand the three algorithms and their limitations.
