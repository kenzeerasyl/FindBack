"""Search operations shared by the local server and the browser worker."""
import json
from pathlib import Path
from secrets import token_urlsafe

from .decision_model import Action
from .scenarios import load_scenarios
from .session import SearchSession


class SearchService:
    def __init__(self, root):
        root = Path(root)
        self.scenarios = load_scenarios(root / 'scenarios.json')
        self.experiments = json.loads((root / 'results' / 'summary.json').read_text(encoding='utf-8'))
        self.sessions = {}

    def config(self):
        return {
            'scenarios': [
                dict(id=key, name=s.name, description=s.description, budget=s.budget,
                     locations=[name for name, _ in s.campus.locations])
                for key, s in self.scenarios.items()
            ],
            'experiments': self.experiments,
        }

    def operate(self, payload):
        operation = payload['operation']
        token = payload.get('session')
        if operation in ('start', 'restore'):
            settings = payload['settings'] if operation == 'restore' else payload
            scenario_id = settings['scenario']
            session = SearchSession(
                self.scenarios[scenario_id], settings['item'], settings['mode'], settings['seed'],
                settings['depth'], settings['budget'], settings.get('start_at', ''),
                settings.get('last_seen', ''), settings.get('description', ''),
            )
            if operation == 'restore':
                session.replay(payload['events'])
            self.sessions.pop(token, None)
            token = token_urlsafe(24)
            self.sessions[token] = (session, scenario_id)
            if len(self.sessions) > 24:
                del self.sessions[next(iter(self.sessions))]
        else:
            if token not in self.sessions:
                raise ValueError('Session expired. Start a new search.')
            session, scenario_id = self.sessions[token]
            if payload.get('revision') != session.revision:
                raise ValueError('This search changed in another request. Refresh or start a new search.')
            if session.revision >= 200:
                raise ValueError('This search has reached its history limit. Start a new search.')
            if operation == 'action':
                session.apply(Action(payload['kind'], payload.get('target', '')), payload.get('outcome'))
            elif operation == 'report':
                session.report(payload['target'], payload['outcome'], payload['report_id'], payload.get('note', ''))
            elif operation == 'toggle':
                session.toggle_cell(payload['row'], payload['col'])
            else:
                raise ValueError('Unknown operation.')
        return {'session': token, 'scenario_id': scenario_id, 'state': session.snapshot()}
